
export interface Character {
  id: number;
  name: string;
  role: string;
  village: string;
  image: string;
  bio: string;
  jutsus: string[];
  notableArcs: string[];
  favoriteQuote?: string;
  transformations: {
    name: string;
    description: string;
  }[];
}

export const characters: Character[] = [
  {
    id: 1,
    name: 'Naruto Uzumaki',
    role: 'Jinchūriki / Hokage',
    village: 'Hidden Leaf',
    image: 'https://staticg.sportskeeda.com/editor/2022/08/53e15-16596004347246.png',
    bio: 'Naruto is the protagonist of the series. Born with the Nine-Tailed Fox sealed within him, he faced discrimination throughout his childhood. Despite his hardships, Naruto aspires to become the Hokage, the leader of his village, to earn recognition and respect.',
    jutsus: ['Rasengan', 'Shadow Clone Technique', 'Sage Mode', 'Tailed Beast Mode'],
    notableArcs: ['Chunin Exams', "Pain's Assault", 'Fourth Great Ninja War'],
    favoriteQuote: "I'm not gonna run away, I never go back on my word! That's my nindo: my ninja way!",
    transformations: [
      {
        name: 'Nine-Tails Chakra Mode',
        description: 'After gaining control over Kurama\'s chakra, Naruto can enter this form which greatly enhances his abilities.'
      },
      {
        name: 'Six Paths Sage Mode',
        description: 'Gained from the Sage of Six Paths, this form grants Naruto immense power and the ability to use Truth-Seeking Balls.'
      }
    ]
  },
  {
    id: 2,
    name: 'Sasuke Uchiha',
    role: 'Avenger / Wandering Shinobi',
    village: 'Hidden Leaf',
    image: 'https://staticg.sportskeeda.com/editor/2022/08/9d35d-16597340972914-1920.jpg',
    bio: 'Sasuke is Naruto\'s rival and the last surviving member of the Uchiha clan in Konoha. After his family was killed by his brother Itachi, Sasuke\'s sole ambition was to gain power and exact revenge, leading him down a dark path.',
    jutsus: ['Chidori', 'Amaterasu', 'Susanoo', 'Rinnegan'],
    notableArcs: ['Sasuke Retrieval', 'Uchiha Brothers Confrontation', 'Fourth Great Ninja War'],
    favoriteQuote: "I have long since closed my eyes... My only goal is in the darkness.",
    transformations: [
      {
        name: 'Cursed Seal Transformation',
        description: 'Granted by Orochimaru, this transformation significantly increases Sasuke\'s power.'
      },
      {
        name: 'Eternal Mangekyō Sharingan',
        description: 'An enhanced version of the Mangekyō Sharingan that doesn\'t deteriorate with use.'
      }
    ]
  },
  {
    id: 3,
    name: 'Sakura Haruno',
    role: 'Medical Ninja',
    village: 'Hidden Leaf',
    image: 'https://staticg.sportskeeda.com/editor/2022/01/79548-16431004113131-1920.jpg',
    bio: 'Sakura is a member of Team 7 alongside Naruto and Sasuke. Initially weak and obsessed with Sasuke, she trains under Tsunade to become a formidable medical ninja and develops incredible strength.',
    jutsus: ['Chakra Enhanced Strength', 'Mystical Palm Technique', 'Summoning Technique (Katsuyu)'],
    notableArcs: ['Chunin Exams', 'Sasuke Retrieval', 'Fourth Great Ninja War'],
    transformations: [
      {
        name: 'Hundred Healings Seal',
        description: 'A technique learned from Tsunade that allows Sakura to store vast amounts of chakra for healing and combat.'
      }
    ]
  },
  {
    id: 4,
    name: 'Kakashi Hatake',
    role: 'Jonin / Hokage',
    village: 'Hidden Leaf',
    image: 'https://staticg.sportskeeda.com/editor/2021/09/c5705-16324144403443-800.jpg',
    bio: 'Known as the "Copy Ninja" for his use of the Sharingan to copy over a thousand jutsu. Kakashi is the leader of Team 7 and mentor to Naruto, Sasuke, and Sakura.',
    jutsus: ['Chidori', 'Lightning Blade', 'Kamui', 'Water Dragon Bullet'],
    notableArcs: ['Land of Waves', 'Kakashi Gaiden', "Pain's Assault"],
    transformations: [
      {
        name: 'Mangekyō Sharingan',
        description: 'Kakashi\'s Mangekyō Sharingan allows him to use Kamui, a space-time ninjutsu.'
      },
      {
        name: 'Perfect Susanoo',
        description: 'Temporarily gained when Obito\'s spirit grants him both Sharingan during the war.'
      }
    ]
  },
  {
    id: 5,
    name: 'Itachi Uchiha',
    role: 'Akatsuki Member / ANBU',
    village: 'Hidden Leaf (formerly)',
    image: 'https://staticg.sportskeeda.com/editor/2022/06/a0b91-16559259513246-1920.jpg',
    bio: 'Sasuke\'s older brother who massacred the entire Uchiha clan, sparing only Sasuke. His true motives were much more complex than they initially appeared.',
    jutsus: ['Amaterasu', 'Tsukuyomi', 'Susanoo', 'Izanami'],
    notableArcs: ['Uchiha Clan Downfall', 'Search for Tsunade', 'Itachi Pursuit Mission'],
    transformations: [
      {
        name: 'Mangekyō Sharingan',
        description: 'Grants Itachi access to powerful techniques like Amaterasu and Tsukuyomi.'
      },
      {
        name: 'Susanoo',
        description: 'A gigantic, humanoid avatar made of chakra that surrounds Itachi and fights on his behalf.'
      }
    ]
  },
  {
    id: 6,
    name: 'Hinata Hyuga',
    role: 'Byakugan Princess',
    village: 'Hidden Leaf',
    image: 'https://staticg.sportskeeda.com/editor/2022/08/4e66e-16596012203137-1920.jpg',
    bio: 'A member of the prestigious Hyuga clan and possessor of the Byakugan. Hinata harbors deep feelings for Naruto from their childhood and gradually builds confidence throughout the series.',
    jutsus: ['Gentle Fist', 'Eight Trigrams Sixty-Four Palms', 'Twin Lion Fists'],
    notableArcs: ['Chunin Exams', "Pain's Assault", 'The Last: Naruto the Movie'],
    transformations: [
      {
        name: 'Byakugan',
        description: 'A dōjutsu that gives Hinata near-360° vision and the ability to see chakra.'
      }
    ]
  },
  {
    id: 7,
    name: 'Jiraiya',
    role: 'Legendary Sannin',
    village: 'Hidden Leaf',
    image: 'https://staticg.sportskeeda.com/editor/2022/06/37e2c-16552869573908-1920.jpg',
    bio: 'One of the Legendary Sannin and Naruto\'s godfather and mentor. Known as the "Toad Sage," Jiraiya was also a renowned author of adult literature.',
    jutsus: ['Rasengan', 'Summoning Technique (Toads)', 'Sage Mode', 'Toad Oil Flame Bullet'],
    notableArcs: ['Search for Tsunade', 'Naruto\'s Training', 'Pain Arc'],
    transformations: [
      {
        name: 'Sage Mode',
        description: 'Enhances Jiraiya\'s physical abilities and allows him to use powerful nature energy.'
      }
    ]
  },
  {
    id: 8,
    name: 'Tsunade',
    role: 'Legendary Sannin / Hokage',
    village: 'Hidden Leaf',
    image: 'https://staticg.sportskeeda.com/editor/2022/08/53ac0-16602291001918-1920.jpg',
    bio: 'One of the Legendary Sannin and the Fifth Hokage. Renowned for her medical ninjutsu, youthful appearance despite her age, and formidable strength.',
    jutsus: ['Strength of a Hundred Seal', 'Creation Rebirth', 'Nervous System Rupture', 'Summoning Technique (Katsuyu)'],
    notableArcs: ['Search for Tsunade', "Pain's Assault", 'Fourth Great Ninja War'],
    transformations: [
      {
        name: 'Strength of a Hundred Seal',
        description: 'A seal that stores vast amounts of chakra over time, allowing for techniques like Creation Rebirth.'
      }
    ]
  },
  {
    id: 9,
    name: 'Gaara',
    role: 'Jinchūriki / Kazekage',
    village: 'Hidden Sand',
    image: 'https://staticg.sportskeeda.com/editor/2022/08/ef125-16602351841911-1920.jpg',
    bio: 'Once a feared weapon of the Sand Village as the Jinchūriki of Shukaku, Gaara was transformed by his encounter with Naruto. He overcame his violent past to become the respected Kazekage of his village.',
    jutsus: ['Sand Manipulation', 'Sand Shield', 'Sand Burial', 'Desert Coffin'],
    notableArcs: ['Chunin Exams', 'Kazekage Rescue', 'Fourth Great Ninja War'],
    favoriteQuote: "The corpse's bitter crimson tears flow and mingle with the endless sand, filling the chaos within me - and making me stronger.",
    transformations: [
      {
        name: 'Shukaku Transformation',
        description: 'Gaara could partially or fully transform into Shukaku, the One-Tailed Beast, greatly increasing his sand manipulation abilities.'
      }
    ]
  },
  {
    id: 10,
    name: 'Rock Lee',
    role: 'Taijutsu Specialist',
    village: 'Hidden Leaf',
    image: 'https://staticg.sportskeeda.com/editor/2022/08/56a4f-16598167146029-1920.jpg',
    bio: 'Unable to use ninjutsu or genjutsu, Lee dedicated himself to mastering taijutsu under the guidance of Might Guy. His determination to succeed through hard work alone makes him a formidable ninja despite his limitations.',
    jutsus: ['Eight Inner Gates', 'Primary Lotus', 'Hidden Lotus', 'Drunken Fist'],
    notableArcs: ['Chunin Exams', 'Sasuke Retrieval', 'Fourth Great Ninja War'],
    favoriteQuote: "A dropout will beat a genius through hard work!",
    transformations: [
      {
        name: 'Eight Gates Released',
        description: 'Opening the Eight Inner Gates gives Lee tremendous power at the risk of severe physical damage.'
      }
    ]
  },
  {
    id: 11,
    name: 'Shikamaru Nara',
    role: 'Tactical Genius / Advisor',
    village: 'Hidden Leaf',
    image: 'https://staticg.sportskeeda.com/editor/2022/07/3fa7c-16571702042562-1920.jpg',
    bio: 'The lazy but brilliant strategist of the Leaf Village. Despite his reluctance to exert himself, Shikamaru\'s exceptional intellect makes him an invaluable asset in battle planning and strategy.',
    jutsus: ['Shadow Possession Jutsu', 'Shadow Strangle Jutsu', 'Shadow Sewing Technique'],
    notableArcs: ['Chunin Exams', 'Hidan and Kakuzu Arc', 'Fourth Great Ninja War'],
    favoriteQuote: "What a drag...",
    transformations: []
  },
  {
    id: 12,
    name: 'Neji Hyuga',
    role: 'Byakugan Prodigy',
    village: 'Hidden Leaf',
    image: 'https://staticg.sportskeeda.com/editor/2022/07/8a8f9-16573642906057-1920.jpg',
    bio: 'Born into the Branch House of the Hyuga clan, Neji was a prodigy who initially resented the Main House due to the caged bird seal and his father\'s fate. His encounter with Naruto changed his perspective on destiny.',
    jutsus: ['Gentle Fist', 'Eight Trigrams Sixty-Four Palms', 'Palm Rotation'],
    notableArcs: ['Chunin Exams', 'Sasuke Retrieval', 'Fourth Great Ninja War'],
    favoriteQuote: "People are born with a destiny they cannot oppose.",
    transformations: []
  },
  {
    id: 13,
    name: 'Orochimaru',
    role: 'Legendary Sannin / Scientist',
    village: 'Hidden Sound (formerly Hidden Leaf)',
    image: 'https://staticg.sportskeeda.com/editor/2021/09/bd560-16305885264352-800.jpg',
    bio: 'One of the Legendary Sannin who was consumed by his desire for immortality and forbidden jutsu. Orochimaru performed inhumane experiments and created the Hidden Sound Village as his base of operations.',
    jutsus: ['Immortality Technique', 'Summoning: Reanimation', 'Body Transfer', 'Eight Branches Technique'],
    notableArcs: ['Chunin Exams', 'Search for Tsunade', 'Tenchi Bridge Reconnaissance'],
    favoriteQuote: "It's human nature not to realize the true value of something, unless they lose it.",
    transformations: [
      {
        name: 'White Snake Form',
        description: 'Orochimaru\'s true form is a large white snake made up of many smaller snakes.'
      }
    ]
  },
  {
    id: 14,
    name: 'Madara Uchiha',
    role: 'Uchiha Clan Leader / Legendary Shinobi',
    village: 'Hidden Leaf (formerly)',
    image: 'https://staticg.sportskeeda.com/editor/2022/06/3e6d5-16559241979398-1920.jpg',
    bio: 'A legendary shinobi and co-founder of the Hidden Leaf Village. Madara\'s disillusionment with the shinobi world led him to develop the Eye of the Moon Plan to cast an eternal genjutsu on humanity.',
    jutsus: ['Susanoo', 'Eternal Mangekyō Sharingan', 'Rinnegan', 'Wood Style'],
    notableArcs: ['Uchiha Clan Downfall', 'Fourth Great Ninja War'],
    favoriteQuote: "Wake up to reality! Nothing ever goes as planned in this world. The longer you live, the more you realize that only pain, suffering, and futility exist in this reality.",
    transformations: [
      {
        name: 'Perfect Susanoo',
        description: 'The ultimate form of Susanoo, capable of cutting mountains with a single swing of its sword.'
      },
      {
        name: 'Ten-Tails Jinchūriki',
        description: 'After becoming the Ten-Tails Jinchūriki, Madara gained godlike powers and near-immortality.'
      }
    ]
  },
  {
    id: 15,
    name: 'Obito Uchiha',
    role: 'Akatsuki / Masked Man',
    village: 'Hidden Leaf (formerly)',
    image: 'https://staticg.sportskeeda.com/editor/2022/06/e7c64-16558495574564-1920.jpg',
    bio: 'Presumed dead after the Third Shinobi World War, Obito was saved and corrupted by Madara. Taking on the identity of Tobi and later posing as Madara himself, he orchestrated much of the Fourth Great Ninja War.',
    jutsus: ['Kamui', 'Wood Style', 'Six Paths Technique', 'Truth-Seeking Balls'],
    notableArcs: ['Kakashi Gaiden', "Pain's Assault", 'Fourth Great Ninja War'],
    favoriteQuote: "In a world of lies, what is reality?",
    transformations: [
      {
        name: 'Ten-Tails Jinchūriki',
        description: 'As the Ten-Tails Jinchūriki, Obito gained immense power and the ability to use Truth-Seeking Balls.'
      }
    ]
  },
  {
    id: 16,
    name: 'Pain (Nagato)',
    role: 'Akatsuki Leader / Six Paths of Pain',
    village: 'Hidden Rain',
    image: 'https://staticg.sportskeeda.com/editor/2022/08/b7c29-16600845371075-1920.jpg',
    bio: 'Originally Nagato Uzumaki, he was orphaned during war and later manipulated by Obito. Using his Rinnegan, he controlled six bodies known as the Six Paths of Pain, seeking to bring peace through pain and suffering.',
    jutsus: ['Six Paths Technique', 'Almighty Push', 'Planetary Devastation', 'Soul Removal'],
    notableArcs: ['Tale of Jiraiya the Gallant', "Pain's Assault", 'Fourth Great Ninja War'],
    favoriteQuote: "Those who do not understand true pain can never understand true peace.",
    transformations: []
  }
];
