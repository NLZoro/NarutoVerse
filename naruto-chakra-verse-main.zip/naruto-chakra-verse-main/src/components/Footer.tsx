
import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-naruto-darkBlue border-t border-gray-800">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-naruto-orange rounded-full flex items-center justify-center">
                <span className="font-bold text-white">N</span>
              </div>
              <span className="text-xl font-bold text-white">NarutoChakaVerse</span>
            </Link>
            <p className="text-gray-400 text-sm mt-4">
              Your ultimate destination for everything in the Naruto universe. Explore episodes, characters, jutsu and more.
            </p>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4">Navigate</h4>
            <ul className="space-y-2">
              <li><Link to="/" className="text-gray-400 hover:text-naruto-orange transition-colors">Home</Link></li>
              <li><Link to="/episodes" className="text-gray-400 hover:text-naruto-orange transition-colors">Episodes</Link></li>
              <li><Link to="/characters" className="text-gray-400 hover:text-naruto-orange transition-colors">Characters</Link></li>
              <li><Link to="/jutsu" className="text-gray-400 hover:text-naruto-orange transition-colors">Jutsu & Powers</Link></li>
              <li><Link to="/lore" className="text-gray-400 hover:text-naruto-orange transition-colors">Lore</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4">Categories</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-naruto-orange transition-colors">Naruto</a></li>
              <li><a href="#" className="text-gray-400 hover:text-naruto-orange transition-colors">Naruto Shippuden</a></li>
              <li><a href="#" className="text-gray-400 hover:text-naruto-orange transition-colors">Boruto</a></li>
              <li><a href="#" className="text-gray-400 hover:text-naruto-orange transition-colors">Movies</a></li>
              <li><a href="#" className="text-gray-400 hover:text-naruto-orange transition-colors">OVAs</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4">Connect</h4>
            <div className="flex space-x-4 mb-4">
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-naruto-orange hover:text-white transition-colors">
                <span>X</span>
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-naruto-orange hover:text-white transition-colors">
                <span>FB</span>
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-naruto-orange hover:text-white transition-colors">
                <span>IG</span>
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-naruto-orange hover:text-white transition-colors">
                <span>YT</span>
              </a>
            </div>
            <p className="text-gray-400 text-sm">Subscribe to our newsletter for updates</p>
            <div className="mt-2 flex">
              <input 
                type="email" 
                placeholder="Your email" 
                className="bg-gray-800 text-gray-200 px-4 py-2 rounded-l-md focus:outline-none"
              />
              <button className="bg-naruto-orange px-4 py-2 rounded-r-md text-white">
                Join
              </button>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-500 text-sm">
          <p>© {new Date().getFullYear()} NarutoChakaVerse. All rights reserved.</p>
          <p className="mt-2">This is a fan-made website. Naruto and all related properties are trademarks of Masashi Kishimoto/Shueisha/Studio Pierrot/TV Tokyo.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
