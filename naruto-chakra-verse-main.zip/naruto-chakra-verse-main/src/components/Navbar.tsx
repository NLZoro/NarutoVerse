
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const navLinks = [
    { path: '/', label: 'Home' },
    { path: '/episodes', label: 'Episodes' },
    { path: '/characters', label: 'Characters' },
    { path: '/jutsu', label: 'Jutsu & Powers' },
    { path: '/lore', label: 'Lore' },
  ];
  
  const isActive = (path: string) => location.pathname === path;
  
  return (
    <header 
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        scrolled ? 'bg-naruto-darkBlue/95 backdrop-blur-lg shadow-lg' : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div className="w-10 h-10 bg-naruto-orange rounded-full flex items-center justify-center">
            <span className="font-bold text-white">N</span>
          </div>
          <span className="text-xl font-bold text-white">NarutoChakaVerse</span>
        </Link>
        
        {/* Mobile menu button */}
        <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X className="text-white" /> : <Menu className="text-white" />}
        </button>
        
        {/* Desktop menu */}
        <nav className="hidden md:flex items-center gap-6">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`text-sm font-medium relative px-1 py-2 transition-colors ${
                isActive(link.path) 
                  ? 'text-naruto-orange' 
                  : 'text-gray-300 hover:text-white'
              }`}
            >
              {link.label}
              {isActive(link.path) && (
                <span className="absolute bottom-0 left-0 w-full h-0.5 bg-naruto-orange rounded-full" />
              )}
            </Link>
          ))}
          <button className="chakra-btn ml-4">Sign In</button>
        </nav>
      </div>
      
      {/* Mobile menu */}
      {isOpen && (
        <nav className="md:hidden bg-naruto-darkBlue/95 backdrop-blur-lg">
          <div className="container mx-auto py-4 px-4 flex flex-col gap-4">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`text-base font-medium py-2 ${
                  isActive(link.path) ? 'text-naruto-orange' : 'text-gray-300'
                }`}
                onClick={() => setIsOpen(false)}
              >
                {link.label}
              </Link>
            ))}
            <button className="chakra-btn my-2">Sign In</button>
          </div>
        </nav>
      )}
    </header>
  );
};

export default Navbar;
