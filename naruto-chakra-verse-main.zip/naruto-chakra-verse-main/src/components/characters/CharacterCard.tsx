
import React from 'react';
import { Info, Heart, Swords, MapPin } from 'lucide-react';
import { HoverCard, HoverCardTrigger, HoverCardContent } from "@/components/ui/hover-card";
import { motion } from "framer-motion";
import { Character } from '@/data/charactersData';
import { cardVariants } from '@/utils/animationVariants';

interface CharacterCardProps {
  character: Character;
  isLoading: boolean;
  onClick: () => void;
}

const CharacterCard: React.FC<CharacterCardProps> = ({ character, isLoading, onClick }) => {
  return (
    <motion.div 
      className="character-card cursor-pointer relative group"
      variants={cardVariants}
      whileHover="hover"
      onClick={onClick}
    >
      <div className="relative aspect-[3/4] overflow-hidden rounded-lg">
        {isLoading ? (
          <div className="w-full h-full bg-secondary/80 animate-pulse flex items-center justify-center">
            <div className="w-12 h-12 border-4 border-naruto-orange border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : (
          <>
            <div className="absolute top-0 right-0 z-10 p-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <HoverCard>
                <HoverCardTrigger asChild>
                  <button className="p-1.5 bg-naruto-darkBlue/80 rounded-full">
                    <Info className="h-4 w-4 text-naruto-orange" />
                  </button>
                </HoverCardTrigger>
                <HoverCardContent className="w-64 bg-naruto-darkBlue border border-naruto-orange/20 p-4 text-sm">
                  <div className="flex flex-col space-y-2">
                    <div className="flex items-center space-x-2">
                      <Heart className="h-4 w-4 text-naruto-red" />
                      <span>{character.jutsus[0]}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Swords className="h-4 w-4 text-naruto-orange" />
                      <span>{character.notableArcs[0]}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <MapPin className="h-4 w-4 text-naruto-gold" />
                      <span>{character.village}</span>
                    </div>
                  </div>
                </HoverCardContent>
              </HoverCard>
            </div>
        
            <img 
              src={character.image} 
              alt={character.name} 
              className="w-full h-full object-cover transform transition-transform duration-700 group-hover:scale-110"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-naruto-darkBlue via-transparent to-transparent"></div>
            <div className="absolute inset-0 bg-naruto-orange/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

            <div className="absolute bottom-0 left-0 w-full p-4 transform transition-transform duration-300 group-hover:translate-y-0">
              <span className="inline-block px-2 py-1 bg-naruto-orange text-white text-xs rounded mb-2 animate-pulse">
                {character.village}
              </span>
              <h3 className="text-white font-bold text-lg">{character.name}</h3>
              <p className="text-gray-300 text-sm">{character.role}</p>
            </div>
            
            <div className="absolute -bottom-full left-0 w-full bg-gradient-to-t from-naruto-orange/80 to-naruto-orange/40 p-4 transform transition-all duration-300 group-hover:bottom-0 group-hover:opacity-100 opacity-0">
              <div className="flex flex-wrap gap-1 mb-2">
                {character.jutsus.slice(0, 2).map((jutsu, index) => (
                  <span key={index} className="px-2 py-0.5 bg-black/30 rounded-full text-xs text-white">
                    {jutsu}
                  </span>
                ))}
              </div>
              <p className="text-xs text-white line-clamp-2">{character.bio.substring(0, 60)}...</p>
            </div>
          </>
        )}
      </div>
      <div className="absolute -inset-0.5 bg-gradient-to-r from-naruto-orange to-naruto-red rounded-lg blur opacity-0 group-hover:opacity-20 transition-opacity duration-300 -z-10"></div>
    </motion.div>
  );
};

export default CharacterCard;
