
import React from 'react';
import { Search } from 'lucide-react';
import { motion } from "framer-motion";

interface CharacterSearchProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

const CharacterSearch: React.FC<CharacterSearchProps> = ({ searchQuery, setSearchQuery }) => {
  return (
    <motion.div 
      className="relative max-w-md mx-auto mb-12"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.3 }}
    >
      <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
      <input
        type="text"
        placeholder="Search characters..."
        className="w-full pl-10 pr-4 py-3 bg-secondary rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-naruto-orange"
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
      />
    </motion.div>
  );
};

export default CharacterSearch;
