
import React from 'react';
import { X } from 'lucide-react';
import { motion } from "framer-motion";
import { Character } from '@/data/charactersData';
import { modalVariants } from '@/utils/animationVariants';

interface CharacterDetailModalProps {
  character: Character;
  onClose: () => void;
}

const CharacterDetailModal: React.FC<CharacterDetailModalProps> = ({ character, onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div 
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
      ></div>
      
      <motion.div 
        className="relative bg-naruto-darkBlue border border-naruto-orange/20 rounded-lg w-full max-w-4xl max-h-[90vh] overflow-y-auto"
        variants={modalVariants}
        initial="hidden"
        animate="visible"
        exit="hidden"
      >
        <button 
          className="absolute top-4 right-4 p-2 bg-gray-800 rounded-full hover:bg-naruto-orange/80 transition-colors"
          onClick={onClose}
        >
          <X className="text-white h-5 w-5" />
        </button>
        
        <div className="grid grid-cols-1 md:grid-cols-3">
          <motion.div 
            className="md:col-span-1"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.4, delay: 0.2 }}
          >
            <div className="relative aspect-[3/4] w-full">
              <img 
                src={character.image} 
                alt={character.name} 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-naruto-darkBlue/80 to-transparent"></div>
            </div>
          </motion.div>
          
          <motion.div 
            className="md:col-span-2 p-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.4, delay: 0.3 }}
          >
            <motion.span 
              className="inline-block px-2 py-1 bg-naruto-orange text-white text-xs rounded"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.4 }}
            >
              {character.village}
            </motion.span>
            <motion.h2 
              className="text-3xl font-bold mt-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.5 }}
            >
              {character.name}
            </motion.h2>
            <motion.p 
              className="text-gray-300 mb-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.6 }}
            >
              {character.role}
            </motion.p>
            
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.7 }}
            >
              <h3 className="text-lg font-bold mb-2">Biography</h3>
              <p className="text-gray-300 mb-6">{character.bio}</p>
              
              {character.favoriteQuote && (
                <div className="mb-6 p-4 border-l-4 border-naruto-orange bg-secondary/40 italic">
                  "{character.favoriteQuote}"
                </div>
              )}
              
              <h3 className="text-lg font-bold mb-2">Notable Jutsu</h3>
              <div className="flex flex-wrap gap-2 mb-6">
                {character.jutsus.map((jutsu, index) => (
                  <motion.span 
                    key={index} 
                    className="px-3 py-1 bg-secondary rounded-full text-sm"
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.3, delay: 0.1 * index }}
                    whileHover={{ scale: 1.1, backgroundColor: "#F97316" }}
                  >
                    {jutsu}
                  </motion.span>
                ))}
              </div>
              
              <h3 className="text-lg font-bold mb-2">Notable Arcs</h3>
              <div className="flex flex-wrap gap-2 mb-6">
                {character.notableArcs.map((arc, index) => (
                  <motion.span 
                    key={index} 
                    className="px-3 py-1 bg-secondary rounded-full text-sm"
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.3, delay: 0.1 * index + 0.3 }}
                    whileHover={{ scale: 1.1, backgroundColor: "#ea384c" }}
                  >
                    {arc}
                  </motion.span>
                ))}
              </div>
              
              {character.transformations.length > 0 && (
                <>
                  <h3 className="text-lg font-bold mb-2">Transformations</h3>
                  <div className="space-y-4">
                    {character.transformations.map((transformation, index) => (
                      <motion.div 
                        key={index} 
                        className="bg-secondary/50 p-4 rounded-lg border border-naruto-orange/10 hover:border-naruto-orange/30 transition-colors"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4, delay: 0.2 * index + 0.5 }}
                        whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(249, 115, 22, 0.2)" }}
                      >
                        <h4 className="font-bold text-naruto-orange">{transformation.name}</h4>
                        <p className="text-gray-300 text-sm">{transformation.description}</p>
                      </motion.div>
                    ))}
                  </div>
                </>
              )}
            </motion.div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
};

export default CharacterDetailModal;
