
import React, { useState, useEffect } from 'react';

interface Leaf {
  id: number;
  left: string;
  delay: string;
  duration: string;
  rotation: string;
}

const BackgroundEffects: React.FC = () => {
  const [leaves, setLeaves] = useState<Leaf[]>([]);

  useEffect(() => {
    // Create falling leaves effect
    const generateLeaves = () => {
      const numberOfLeaves = 20;
      const newLeaves = [];
      
      for (let i = 0; i < numberOfLeaves; i++) {
        newLeaves.push({
          id: i,
          left: `${Math.random() * 100}%`,
          delay: `${Math.random() * 5}s`,
          duration: `${Math.random() * 5 + 10}s`,
          rotation: `${Math.random() * 360}deg`
        });
      }
      
      setLeaves(newLeaves);
    };
    
    generateLeaves();
    
    // Regenerate leaves every 20 seconds for continuous effect
    const interval = setInterval(generateLeaves, 20000);
    return () => clearInterval(interval);
  }, []);

  // SVG for leaf
  const leafSvg = (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12" 
        stroke="#4CAF50" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M22 2L12 12" stroke="#4CAF50" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M16 8H8V16H16V8Z" stroke="#4CAF50" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );

  return (
    <div className="leaf-bg">
      {leaves.map((leaf) => (
        <div
          key={leaf.id}
          className="absolute animate-leaf-fall opacity-30"
          style={{
            left: leaf.left,
            animationDelay: leaf.delay,
            animationDuration: leaf.duration,
            transform: `rotate(${leaf.rotation})`,
          }}
        >
          {leafSvg}
        </div>
      ))}
      
      {/* Chakra energy orbs */}
      <div className="fixed bottom-0 left-1/4 w-[300px] h-[300px] rounded-full bg-naruto-orange/5 filter blur-3xl"></div>
      <div className="fixed top-1/4 right-1/3 w-[200px] h-[200px] rounded-full bg-naruto-red/5 filter blur-3xl"></div>
      <div className="fixed top-2/3 right-1/4 w-[250px] h-[250px] rounded-full bg-naruto-chakra/5 filter blur-3xl"></div>
    </div>
  );
};

export default BackgroundEffects;
