import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Play } from 'lucide-react';

const HomePage: React.FC = () => {
  const featuredSectionRef = useRef<HTMLDivElement>(null);
  
  // Mock data for featured episodes
  const featuredEpisodes = [
    {
      id: 1,
      title: 'The Final Battle',
      episode: 'Shippuden Ep. 476',
      image: 'https://staticg.sportskeeda.com/editor/2021/02/a257c-16142289465510-800.jpg',
      description: 'Naruto and Sasuke face off in their final confrontation.'
    },
    {
      id: 2,
      title: 'Kurama Unleashed',
      episode: 'Shippuden Ep. 329',
      image: 'https://staticg.sportskeeda.com/editor/2023/03/2ba54-16776578934881-1920.jpg',
      description: 'Naruto gains control of the Nine-Tails chakra.'
    },
    {
      id: 3,
      title: 'The Fourth Hokage',
      episode: 'Shippuden Ep. 174',
      image: 'https://staticg.sportskeeda.com/editor/2022/08/96d1e-16596004953889-1920.jpg',
      description: 'Naruto meets his father for the first time.'
    },
    {
      id: 4,
      title: 'Sage Mode Perfected',
      episode: 'Shippuden Ep. 164',
      image: 'https://staticg.sportskeeda.com/editor/2023/01/7c9c5-16738309536426-1920.jpg',
      description: 'Naruto completes his Sage Mode training.'
    },
    {
      id: 5,
      title: 'Pain\'s Assault',
      episode: 'Shippuden Ep. 163',
      image: 'https://staticg.sportskeeda.com/editor/2022/08/f49fe-16596007548686-1920.jpg',
      description: 'The Hidden Leaf Village faces its greatest threat.'
    },
    {
      id: 6,
      title: 'Itachi\'s Truth',
      episode: 'Shippuden Ep. 141',
      image: 'https://staticg.sportskeeda.com/editor/2021/08/bde15-16302343897925-800.jpg',
      description: 'Sasuke learns the truth about his brother.'
    }
  ];
  
  // Horizontal scroll on drag
  useEffect(() => {
    const slider = featuredSectionRef.current;
    let isDown = false;
    let startX: number;
    let scrollLeft: number;
    
    if (slider) {
      slider.addEventListener('mousedown', (e) => {
        isDown = true;
        slider.classList.add('cursor-grabbing');
        startX = e.pageX - slider.offsetLeft;
        scrollLeft = slider.scrollLeft;
      });
      
      slider.addEventListener('mouseleave', () => {
        isDown = false;
        slider.classList.remove('cursor-grabbing');
      });
      
      slider.addEventListener('mouseup', () => {
        isDown = false;
        slider.classList.remove('cursor-grabbing');
      });
      
      slider.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        e.preventDefault();
        const x = e.pageX - slider.offsetLeft;
        const walk = (x - startX) * 2;
        slider.scrollLeft = scrollLeft - walk;
      });
    }
    
    return () => {
      if (slider) {
        slider.removeEventListener('mousedown', () => {});
        slider.removeEventListener('mouseleave', () => {});
        slider.removeEventListener('mouseup', () => {});
        slider.removeEventListener('mousemove', () => {});
      }
    };
  }, []);
  
  return (
    <div className="relative">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-background z-10" />
        <div className="absolute inset-0 bg-[url('https://wallpapers.com/images/hd/naruto-sage-mode-art-a2mz59h7ojztyk0z.jpg')] bg-cover bg-center opacity-30" />
        
        {/* Animated Rasengan Effect */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] rounded-full bg-naruto-chakra/30 animate-rasengan-spin filter blur-xl"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[200px] h-[200px] rounded-full bg-naruto-orange/40 animate-rasengan-spin filter blur-md"></div>
        
        <div className="container mx-auto px-4 text-center relative z-20">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 text-white">
            <span className="text-naruto-orange">Naruto</span>ChakraVerse
          </h1>
          <p className="text-lg md:text-xl text-gray-300 max-w-2xl mx-auto mb-8">
            Explore the world of shinobi, powerful jutsu, and the legendary tales of the Hidden Leaf Village
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/episodes" className="chakra-btn animate-chakra-pulse">
              Start Watching
              <Play className="ml-2 h-4 w-4" />
            </Link>
            <Link to="/characters" className="bg-transparent border-2 border-naruto-orange text-white hover:bg-naruto-orange/10 font-bold px-6 py-3 rounded-md transition-all duration-300">
              Explore Characters
            </Link>
          </div>
          
          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 14l-7 7m0 0l-7-7m7 7V3"></path>
            </svg>
          </div>
        </div>
      </section>
      
      {/* Featured Episodes Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-10">
            <h2 className="text-3xl font-bold naruto-heading">Featured Episodes</h2>
            <Link to="/episodes" className="text-naruto-orange flex items-center hover:underline">
              View All <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </div>
          
          <div 
            ref={featuredSectionRef}
            className="flex overflow-x-auto space-x-6 pb-6 cursor-grab hide-scrollbar"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {featuredEpisodes.map((episode) => (
              <div key={episode.id} className="flex-shrink-0 w-[300px]">
                <div className="episode-card h-full flex flex-col">
                  <div className="relative h-40 overflow-hidden">
                    <img 
                      src={episode.image} 
                      alt={episode.title} 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-naruto-darkBlue to-transparent"></div>
                    <span className="absolute bottom-2 left-2 text-xs bg-naruto-orange px-2 py-1 rounded text-white">
                      {episode.episode}
                    </span>
                    <button className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-naruto-orange/80 p-3 rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
                      <Play className="h-5 w-5 text-white" />
                    </button>
                  </div>
                  <div className="p-4 flex-grow flex flex-col">
                    <h3 className="font-bold text-lg mb-1">{episode.title}</h3>
                    <p className="text-gray-400 text-sm flex-grow">{episode.description}</p>
                    <button className="mt-4 text-naruto-orange text-sm font-medium flex items-center">
                      Watch Now <ArrowRight className="ml-1 h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Featured Characters Preview */}
      <section className="py-16 bg-secondary">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-10 naruto-heading">Popular Characters</h2>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {[
              {name: 'Naruto', image: 'https://staticg.sportskeeda.com/editor/2022/08/53e15-16596004347246.png'},
              {name: 'Sasuke', image: 'https://staticg.sportskeeda.com/editor/2022/08/9d35d-16597340972914-1920.jpg'},
              {name: 'Sakura', image: 'https://staticg.sportskeeda.com/editor/2022/01/79548-16431004113131-1920.jpg'},
              {name: 'Kakashi', image: 'https://staticg.sportskeeda.com/editor/2021/09/c5705-16324144403443-800.jpg'},
              {name: 'Itachi', image: 'https://staticg.sportskeeda.com/editor/2022/06/a0b91-16559259513246-1920.jpg'},
              {name: 'Hinata', image: 'https://staticg.sportskeeda.com/editor/2022/08/4e66e-16596012203137-1920.jpg'}
            ].map((character, index) => (
              <div key={index} className="character-card group">
                <div className="relative aspect-[3/4] overflow-hidden">
                  <img 
                    src={character.image} 
                    alt={character.name} 
                    className="w-full h-full object-cover filter grayscale group-hover:grayscale-0 transition-all duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-naruto-darkBlue via-transparent to-transparent"></div>
                  <div className="absolute bottom-0 left-0 w-full p-3 transform translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                    <span className="inline-block px-2 py-1 bg-naruto-orange text-white text-xs rounded">View Profile</span>
                  </div>
                </div>
                <div className="p-3 text-center">
                  <h3 className="font-bold">{character.name}</h3>
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-10">
            <Link to="/characters" className="chakra-btn inline-flex items-center">
              Explore All Characters <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
      
      {/* Jutsu Preview Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 naruto-heading">Legendary Jutsu</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="jutsu-card p-6 flex flex-col items-center text-center">
              <div className="w-20 h-20 rounded-full bg-naruto-orange/20 flex items-center justify-center mb-4">
                <div className="w-12 h-12 rounded-full bg-naruto-orange animate-pulse"></div>
              </div>
              <h3 className="text-xl font-bold mb-2">Rasengan</h3>
              <p className="text-gray-400 text-sm">The signature jutsu created by the Fourth Hokage and mastered by Naruto.</p>
              <Link to="/jutsu" className="mt-4 text-naruto-orange text-sm hover:underline">Learn more</Link>
            </div>
            
            <div className="jutsu-card p-6 flex flex-col items-center text-center">
              <div className="w-20 h-20 rounded-full bg-naruto-chakra/20 flex items-center justify-center mb-4">
                <div className="w-12 h-12 rounded-full bg-naruto-chakra animate-pulse"></div>
              </div>
              <h3 className="text-xl font-bold mb-2">Chidori</h3>
              <p className="text-gray-400 text-sm">A lightning-based jutsu developed by Kakashi and mastered by Sasuke.</p>
              <Link to="/jutsu" className="mt-4 text-naruto-orange text-sm hover:underline">Learn more</Link>
            </div>
            
            <div className="jutsu-card p-6 flex flex-col items-center text-center">
              <div className="w-20 h-20 rounded-full bg-naruto-red/20 flex items-center justify-center mb-4">
                <div className="w-12 h-12 rounded-full bg-naruto-red animate-pulse"></div>
              </div>
              <h3 className="text-xl font-bold mb-2">Sharingan</h3>
              <p className="text-gray-400 text-sm">The powerful dōjutsu kekkei genkai of the Uchiha clan.</p>
              <Link to="/jutsu" className="mt-4 text-naruto-orange text-sm hover:underline">Learn more</Link>
            </div>
          </div>
        </div>
      </section>
      
      {/* Call to Action */}
      <section className="py-16 bg-naruto-darkBlue relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1580980379270-570a7b5c34fd?q=80&w=1080&auto=format&fit=crop')] bg-cover bg-center opacity-10"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Begin Your Ninja Journey</h2>
            <p className="text-gray-300 mb-8">Join thousands of fans exploring the rich world of Naruto, from epic battles to heartfelt friendships and unforgettable jutsu.</p>
            <Link to="/episodes" className="chakra-btn inline-flex items-center">
              Start Watching Now <Play className="ml-2 h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
