
import React, { useState, useEffect } from 'react';
import { motion } from "framer-motion";
import { characters } from '@/data/charactersData';
import { containerVariants } from '@/utils/animationVariants';
import CharacterCard from '@/components/characters/CharacterCard';
import CharacterDetailModal from '@/components/characters/CharacterDetailModal';
import CharacterSearch from '@/components/characters/CharacterSearch';
import type { Character } from '@/data/charactersData';

const CharactersPage: React.FC = () => {
  const [selectedCharacter, setSelectedCharacter] = useState<Character | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 600);
    return () => clearTimeout(timer);
  }, []);
  
  const filteredCharacters = characters.filter(char => 
    char.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    char.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
    char.village.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  return (
    <div className="py-20 px-4">
      <div className="container mx-auto">
        <motion.h1 
          className="text-4xl font-bold mb-2"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          Characters
        </motion.h1>
        <motion.p 
          className="text-gray-400 mb-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          Explore the shinobi of the Naruto universe
        </motion.p>
        
        <CharacterSearch searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
        
        <motion.div 
          className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {filteredCharacters.map((character) => (
            <CharacterCard 
              key={character.id}
              character={character}
              isLoading={isLoading}
              onClick={() => setSelectedCharacter(character)}
            />
          ))}
        </motion.div>
        
        {filteredCharacters.length === 0 && (
          <motion.div 
            className="text-center py-20"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <h3 className="text-2xl font-bold mb-2">No characters found</h3>
            <p className="text-gray-400">Try adjusting your search criteria</p>
          </motion.div>
        )}
      </div>
      
      {selectedCharacter && (
        <CharacterDetailModal 
          character={selectedCharacter} 
          onClose={() => setSelectedCharacter(null)} 
        />
      )}
    </div>
  );
};

export default CharactersPage;
