
import React, { useEffect, useRef } from 'react';

const LorePage: React.FC = () => {
  const timelineRef = useRef<HTMLDivElement>(null);
  
  // Intersection Observer for animation
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-fade-in-right');
            entry.target.classList.remove('opacity-0');
          }
        });
      },
      { threshold: 0.1 }
    );
    
    const timelineItems = document.querySelectorAll('.timeline-item');
    timelineItems.forEach((item) => {
      observer.observe(item);
    });
    
    return () => {
      timelineItems.forEach((item) => {
        observer.unobserve(item);
      });
    };
  }, []);
  
  // Timeline data
  const timelineEvents = [
    {
      id: 1,
      title: 'Naruto\'s Birth',
      period: 'Beginning',
      description: 'Naruto Uzumaki is born to the Fourth Hokage, Minato Namikaze, and Kushina Uzumaki. On the same day, the Nine-Tailed Fox attacks the village, leading Minato to seal the beast within newborn Naruto at the cost of his and Kushina\'s lives.',
      image: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=400&auto=format&fit=crop'
    },
    {
      id: 2,
      title: 'Academy Days',
      period: 'Childhood',
      description: 'Naruto struggles at the Ninja Academy due to his poor chakra control and the village\'s discrimination against him as the Nine-Tails jinchūriki. Despite failing the graduation exam multiple times, he eventually learns the Shadow Clone Technique and becomes a genin.',
      image: 'https://images.unsplash.com/photo-1541562232579-512a21360020?q=80&w=400&auto=format&fit=crop'
    },
    {
      id: 3,
      title: 'Team 7 Formation',
      period: 'Genin Era',
      description: 'Naruto is assigned to Team 7 along with Sasuke Uchiha, Sakura Haruno, and their jonin leader, Kakashi Hatake. Their first major mission takes them to the Land of Waves, where they face the rogue ninja Zabuza and his apprentice Haku.',
      image: 'https://images.unsplash.com/photo-1614851099511-773084f6911d?q=80&w=400&auto=format&fit=crop'
    },
    {
      id: 4,
      title: 'Chunin Exams',
      period: 'Genin Era',
      description: 'Team 7 participates in the Chunin Exams, where they face numerous challenges. During this time, Orochimaru attacks and places a curse mark on Sasuke. Naruto defeats Neji Hyuga in the finals, showcasing his growth and challenging the idea of predetermined fate.',
      image: 'https://images.unsplash.com/photo-1575546595146-b52454282b3c?q=80&w=400&auto=format&fit=crop'
    },
    {
      id: 5,
      title: 'Sasuke Retrieval',
      period: 'Genin Era',
      description: 'Sasuke decides to leave the village to seek power from Orochimaru. Naruto and several other genin form a team to bring him back. Despite an intense battle at the Valley of the End, Naruto fails to stop Sasuke, who continues on his path for revenge.',
      image: 'https://images.unsplash.com/photo-1518826778770-a729fb53327c?q=80&w=400&auto=format&fit=crop'
    },
    {
      id: 6,
      title: 'Training with Jiraiya',
      period: 'Time Skip',
      description: 'Naruto leaves the village to train with Jiraiya, one of the Legendary Sannin. For two and a half years, he improves his skills, learns to better control the Nine-Tails\' chakra, and grows both as a ninja and a person.',
      image: 'https://images.unsplash.com/photo-1564507780908-c2d7062ca3c5?q=80&w=400&auto=format&fit=crop'
    },
    {
      id: 7,
      title: 'Akatsuki Confrontation',
      period: 'Shippuden',
      description: 'Upon returning to the village, Naruto faces the Akatsuki, a group seeking to capture all tailed beasts. He encounters several members, including Deidara and Sasori, during the mission to rescue Gaara, the Kazekage and jinchūriki of the One-Tail.',
      image: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=400&auto=format&fit=crop'
    },
    {
      id: 8,
      title: 'Sage Mode Training',
      period: 'Shippuden',
      description: 'After Jiraiya\'s death at the hands of Pain, Naruto trains at Mount Myoboku to learn Sage Mode. This new power allows him to enhance his physical abilities and sensory perception by balancing natural energy with his own chakra.',
      image: 'https://images.unsplash.com/photo-1541562232579-512a21360020?q=80&w=400&auto=format&fit=crop'
    },
    {
      id: 9,
      title: 'Pain\'s Assault',
      period: 'Shippuden',
      description: 'Pain, the leader of the Akatsuki, attacks the Hidden Leaf Village in search of Naruto. After a devastating battle that nearly destroys the village, Naruto defeats Pain and convinces him to believe in peace, leading Pain to resurrect all those he killed during the attack.',
      image: 'https://images.unsplash.com/photo-1614851099511-773084f6911d?q=80&w=400&auto=format&fit=crop'
    },
    {
      id: 10,
      title: 'Fourth Great Ninja War',
      period: 'Shippuden',
      description: 'The five great nations unite to face Madara Uchiha, Obito Uchiha, and the resurrected Ten-Tails. Naruto gains full control over Kurama\'s chakra and later receives power from the Sage of Six Paths, allowing him to face these formidable enemies.',
      image: 'https://images.unsplash.com/photo-1575546595146-b52454282b3c?q=80&w=400&auto=format&fit=crop'
    },
    {
      id: 11,
      title: 'Final Battle with Sasuke',
      period: 'Shippuden',
      description: 'After defeating Kaguya Otsutsuki, Naruto and Sasuke have their final confrontation at the Valley of the End. The battle ends in a draw, with both losing an arm. Sasuke finally acknowledges Naruto\'s perspective and returns to the village.',
      image: 'https://images.unsplash.com/photo-1518826778770-a729fb53327c?q=80&w=400&auto=format&fit=crop'
    },
    {
      id: 12,
      title: 'Becoming Hokage',
      period: 'Adult Era',
      description: 'Naruto fulfills his lifelong dream by becoming the Seventh Hokage. Now married to Hinata with two children, Boruto and Himawari, he continues to protect the village and work toward maintaining peace in the ninja world.',
      image: 'https://images.unsplash.com/photo-1564507780908-c2d7062ca3c5?q=80&w=400&auto=format&fit=crop'
    }
  ];
  
  return (
    <div className="py-20 px-4">
      <div className="container mx-auto">
        <h1 className="text-4xl font-bold mb-2">Naruto's Journey</h1>
        <p className="text-gray-400 mb-16">Follow the path of Naruto Uzumaki from outcast to Hokage</p>
        
        {/* Timeline */}
        <div ref={timelineRef} className="relative mx-auto max-w-4xl">
          {/* Timeline line */}
          <div className="absolute top-0 bottom-0 left-1/2 w-1 bg-naruto-orange/30 transform -translate-x-1/2"></div>
          
          {/* Timeline events */}
          {timelineEvents.map((event, index) => (
            <div 
              key={event.id} 
              className={`timeline-item relative mb-16 opacity-0 ${
                index % 2 === 0 ? 'left-timeline' : 'right-timeline'
              }`}
            >
              <div className={`flex items-center ${index % 2 === 0 ? 'justify-end' : 'justify-start'}`}>
                <div className={`w-full md:w-5/12 ${index % 2 === 0 ? 'md:pr-8 text-right' : 'md:pl-8 text-left'}`}>
                  <span className="inline-block px-2 py-1 bg-naruto-orange/20 text-naruto-orange text-xs rounded mb-2">
                    {event.period}
                  </span>
                  <h3 className="text-2xl font-bold mb-2">{event.title}</h3>
                  <p className="text-gray-300 text-sm">{event.description}</p>
                </div>
                
                {/* Timeline dot */}
                <div className="absolute left-1/2 transform -translate-x-1/2 w-6 h-6 rounded-full bg-naruto-orange border-4 border-background z-10"></div>
                
                {/* Timeline image */}
                <div className={`hidden md:block w-5/12 ${index % 2 === 0 ? 'md:pl-8' : 'md:pr-8'}`}>
                  <div className="aspect-video overflow-hidden rounded-lg shadow-lg">
                    <img 
                      src={event.image} 
                      alt={event.title} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Additional lore feature */}
        <div className="mt-24 py-16 bg-secondary/50 rounded-2xl">
          <div className="max-w-4xl mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8 text-center">Key Story Arcs</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-naruto-darkBlue p-6 rounded-lg border border-naruto-orange/20">
                <h3 className="text-xl font-bold mb-4">The Land of Waves</h3>
                <p className="text-gray-300 mb-4">
                  Team 7's first major mission where they encounter the rogue ninja Zabuza and his apprentice Haku. This arc established the ninja world's harsh realities and strengthened Team 7's bonds.
                </p>
                <div className="w-full h-1 bg-naruto-orange/30 rounded-full overflow-hidden">
                  <div className="h-full bg-naruto-orange w-1/4"></div>
                </div>
                <div className="mt-2 text-xs text-gray-400">Episodes 6-19</div>
              </div>
              
              <div className="bg-naruto-darkBlue p-6 rounded-lg border border-naruto-orange/20">
                <h3 className="text-xl font-bold mb-4">Chunin Exams</h3>
                <p className="text-gray-300 mb-4">
                  Teams from various villages gather to take the Chunin Exams. This arc introduces many key characters and features Naruto's growth as he faces Neji and challenges destiny.
                </p>
                <div className="w-full h-1 bg-naruto-orange/30 rounded-full overflow-hidden">
                  <div className="h-full bg-naruto-orange w-2/5"></div>
                </div>
                <div className="mt-2 text-xs text-gray-400">Episodes 20-67</div>
              </div>
              
              <div className="bg-naruto-darkBlue p-6 rounded-lg border border-naruto-orange/20">
                <h3 className="text-xl font-bold mb-4">Pain's Assault</h3>
                <p className="text-gray-300 mb-4">
                  Pain attacks the Hidden Leaf Village in search of Naruto. This pivotal arc showcases Naruto's growth and his ability to change even the most determined enemy.
                </p>
                <div className="w-full h-1 bg-naruto-orange/30 rounded-full overflow-hidden">
                  <div className="h-full bg-naruto-orange w-3/4"></div>
                </div>
                <div className="mt-2 text-xs text-gray-400">Shippuden Episodes 152-175</div>
              </div>
              
              <div className="bg-naruto-darkBlue p-6 rounded-lg border border-naruto-orange/20">
                <h3 className="text-xl font-bold mb-4">Fourth Great Ninja War</h3>
                <p className="text-gray-300 mb-4">
                  The five great nations unite to face Madara, Obito, and the Ten-Tails. This arc features the most powerful enemies and showcases Naruto's ultimate powers.
                </p>
                <div className="w-full h-1 bg-naruto-orange/30 rounded-full overflow-hidden">
                  <div className="h-full bg-naruto-orange w-4/5"></div>
                </div>
                <div className="mt-2 text-xs text-gray-400">Shippuden Episodes 261-479</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LorePage;
