
import React, { useState } from 'react';

const JutsuPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('ninjutsu');
  
  interface JutsuType {
    id: string;
    name: string;
    description: string;
  }
  
  const jutsuTypes: JutsuType[] = [
    {
      id: 'ninjutsu',
      name: 'Ninjutsu',
      description: 'Jutsu that requires chakra and hand seals to perform. Techniques that utilize the user\'s chakra to create various effects.'
    },
    {
      id: 'genjutsu',
      name: 'Genjutsu',
      description: 'Illusionary techniques that affect the mind and senses of the target, creating false sensory experiences.'
    },
    {
      id: 'taijutsu',
      name: 'Taijutsu',
      description: 'Physical combat techniques that rely on the user\'s strength, speed, and skill rather than chakra.'
    },
    {
      id: 'kekkei-genkai',
      name: 'Kekkei Genkai',
      description: 'Bloodline abilities that are passed down through specific clans, often combining multiple chakra natures.'
    },
    {
      id: 'dojutsu',
      name: 'Dōjutsu',
      description: 'Visual jutsu that manifest in the eyes, including the Sharingan, Byakugan, and Rinnegan.'
    }
  ];
  
  interface Jutsu {
    id: number;
    name: string;
    type: string;
    user: string;
    description: string;
    chakraLevel: number; // 1-5
    image: string;
  }
  
  const jutsuList: Jutsu[] = [
    // Ninjutsu
    {
      id: 1,
      name: 'Rasengan',
      type: 'ninjutsu',
      user: 'Naruto Uzumaki',
      description: 'A spinning ball of chakra formed in the palm of the hand. Created by the Fourth Hokage, it requires extremely refined chakra control.',
      chakraLevel: 4,
      image: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=300&auto=format&fit=crop'
    },
    {
      id: 2,
      name: 'Chidori',
      type: 'ninjutsu',
      user: 'Sasuke Uchiha',
      description: 'A lightning-based attack that concentrates a high amount of lightning chakra in the user\'s hand. Developed by Kakashi Hatake.',
      chakraLevel: 4,
      image: 'https://images.unsplash.com/photo-1541562232579-512a21360020?q=80&w=300&auto=format&fit=crop'
    },
    {
      id: 3,
      name: 'Shadow Clone Technique',
      type: 'ninjutsu',
      user: 'Naruto Uzumaki',
      description: 'Creates solid copies of the user that can fight independently. Unlike regular clones, shadow clones can use jutsu and transfer experience.',
      chakraLevel: 3,
      image: 'https://images.unsplash.com/photo-1614851099511-773084f6911d?q=80&w=300&auto=format&fit=crop'
    },
    
    // Genjutsu
    {
      id: 4,
      name: 'Tsukuyomi',
      type: 'genjutsu',
      user: 'Itachi Uchiha',
      description: 'An extremely powerful genjutsu that traps the opponent in an illusionary world where time flows differently, allowing for days of torture in mere seconds.',
      chakraLevel: 5,
      image: 'https://images.unsplash.com/photo-1575546595146-b52454282b3c?q=80&w=300&auto=format&fit=crop'
    },
    {
      id: 5,
      name: 'Demonic Illusion: Tree Binding Death',
      type: 'genjutsu',
      user: 'Kurenai Yuhi',
      description: 'A genjutsu that creates the illusion of a tree that binds the opponent, allowing the user to attack freely.',
      chakraLevel: 3,
      image: 'https://images.unsplash.com/photo-1518826778770-a729fb53327c?q=80&w=300&auto=format&fit=crop'
    },
    
    // Taijutsu
    {
      id: 6,
      name: 'Eight Inner Gates',
      type: 'taijutsu',
      user: 'Might Guy',
      description: 'A technique that removes the limitations placed on the body\'s muscles, greatly increasing physical prowess at the cost of damage to the body.',
      chakraLevel: 5,
      image: 'https://images.unsplash.com/photo-1564507780908-c2d7062ca3c5?q=80&w=300&auto=format&fit=crop'
    },
    {
      id: 7,
      name: 'Gentle Fist',
      type: 'taijutsu',
      user: 'Hyuga Clan',
      description: 'A taijutsu style used by the Hyuga clan that targets the chakra pathway system, potentially disabling an opponent\'s ability to use chakra.',
      chakraLevel: 3,
      image: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=300&auto=format&fit=crop'
    },
    
    // Kekkei Genkai
    {
      id: 8,
      name: 'Wood Release',
      type: 'kekkei-genkai',
      user: 'Hashirama Senju',
      description: 'A combination of water and earth chakra natures that allows the user to create and manipulate wood and plant life.',
      chakraLevel: 5,
      image: 'https://images.unsplash.com/photo-1541562232579-512a21360020?q=80&w=300&auto=format&fit=crop'
    },
    {
      id: 9,
      name: 'Ice Release',
      type: 'kekkei-genkai',
      user: 'Haku',
      description: 'A combination of water and wind chakra natures that allows the user to create and manipulate ice.',
      chakraLevel: 4,
      image: 'https://images.unsplash.com/photo-1614851099511-773084f6911d?q=80&w=300&auto=format&fit=crop'
    },
    
    // Dōjutsu
    {
      id: 10,
      name: 'Sharingan',
      type: 'dojutsu',
      user: 'Uchiha Clan',
      description: 'A dōjutsu kekkei genkai that appears in members of the Uchiha clan. It allows the user to see chakra, predict movements, and copy techniques.',
      chakraLevel: 3,
      image: 'https://images.unsplash.com/photo-1575546595146-b52454282b3c?q=80&w=300&auto=format&fit=crop'
    },
    {
      id: 11,
      name: 'Byakugan',
      type: 'dojutsu',
      user: 'Hyuga Clan',
      description: 'A dōjutsu kekkei genkai that gives the user near 360° vision and the ability to see chakra pathways, making it perfect for the Gentle Fist style.',
      chakraLevel: 2,
      image: 'https://images.unsplash.com/photo-1518826778770-a729fb53327c?q=80&w=300&auto=format&fit=crop'
    },
    {
      id: 12,
      name: 'Rinnegan',
      type: 'dojutsu',
      user: 'Pain/Nagato',
      description: 'The most powerful of the Three Great Dōjutsu. It grants the user multiple abilities, including control over attraction and repulsion forces.',
      chakraLevel: 5,
      image: 'https://images.unsplash.com/photo-1564507780908-c2d7062ca3c5?q=80&w=300&auto=format&fit=crop'
    }
  ];
  
  const filteredJutsu = jutsuList.filter(jutsu => jutsu.type === activeTab);
  
  return (
    <div className="py-20 px-4">
      <div className="container mx-auto">
        <h1 className="text-4xl font-bold mb-2">Jutsu & Powers</h1>
        <p className="text-gray-400 mb-12">Explore the powerful techniques used by ninjas in the Naruto universe</p>
        
        {/* Jutsu type tabs */}
        <div className="flex flex-wrap justify-center gap-2 mb-16">
          {jutsuTypes.map((type) => (
            <button
              key={type.id}
              className={`px-6 py-3 rounded-full text-sm font-medium transition-all ${
                activeTab === type.id
                  ? 'bg-naruto-orange text-white'
                  : 'bg-secondary text-gray-300 hover:bg-secondary/70'
              }`}
              onClick={() => setActiveTab(type.id)}
            >
              {type.name}
            </button>
          ))}
        </div>
        
        {/* Active tab description */}
        <div className="max-w-2xl mx-auto text-center mb-12">
          <h2 className="text-2xl font-bold mb-3">
            {jutsuTypes.find(type => type.id === activeTab)?.name}
          </h2>
          <p className="text-gray-300">
            {jutsuTypes.find(type => type.id === activeTab)?.description}
          </p>
        </div>
        
        {/* Jutsu cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredJutsu.map((jutsu) => (
            <div key={jutsu.id} className="jutsu-card overflow-hidden group">
              <div className="relative aspect-video overflow-hidden">
                <img 
                  src={jutsu.image} 
                  alt={jutsu.name} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-naruto-darkBlue via-naruto-darkBlue/70 to-transparent"></div>
                
                {/* Chakra level indicator */}
                <div className="absolute bottom-3 left-3 flex items-center space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <div 
                      key={i} 
                      className={`w-2 h-2 rounded-full ${
                        i < jutsu.chakraLevel ? 'bg-naruto-orange' : 'bg-gray-600'
                      }`}
                    ></div>
                  ))}
                  <span className="text-xs text-gray-300 ml-2">Chakra Level</span>
                </div>
              </div>
              
              <div className="p-5">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="text-xl font-bold">{jutsu.name}</h3>
                  <span className="text-xs bg-secondary px-2 py-1 rounded text-gray-300">
                    {jutsu.user}
                  </span>
                </div>
                
                <p className="text-gray-300 text-sm">{jutsu.description}</p>
                
                {/* Animated chakra effect on hover */}
                <div className="mt-4 relative overflow-hidden h-1 bg-gray-700 rounded-full">
                  <div className="absolute inset-y-0 left-0 bg-naruto-orange w-0 group-hover:w-full transition-all duration-1000 ease-out"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default JutsuPage;
