import React, { useState } from 'react';
import { Search, Filter, Play } from 'lucide-react';

const EpisodesPage: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Mock episode data
  const allEpisodes = [
    // Naruto episodes
    {
      id: 1,
      title: 'Enter: Naruto Uzumaki!',
      number: 1,
      series: 'naruto',
      thumbnail: 'https://staticg.sportskeeda.com/editor/2022/05/d01cc-16530291786971-1920.jpg',
      description: 'Naruto Uzumaki is a young ninja who seeks recognition from his peers.',
      arc: 'Introduction Arc'
    },
    {
      id: 2,
      title: 'My Name is Konohamaru!',
      number: 2,
      series: 'naruto',
      thumbnail: 'https://staticg.sportskeeda.com/editor/2021/09/a5ead-16313441696774-800.jpg',
      description: 'Naruto meets the Third Hokage\'s grandson Konohamaru.',
      arc: 'Introduction Arc'
    },
    {
      id: 3,
      title: 'Sasuke and Sakura: Friends or Foes?',
      number: 3,
      series: 'naruto',
      thumbnail: 'https://staticg.sportskeeda.com/editor/2023/02/0c63d-16759307518472-1920.jpg',
      description: 'The formation of Team 7 with Naruto, Sasuke, and Sakura.',
      arc: 'Introduction Arc'
    },
    {
      id: 4,
      title: 'Pass or Fail: Survival Test',
      number: 4,
      series: 'naruto',
      thumbnail: 'https://staticg.sportskeeda.com/editor/2021/05/90bec-16215974825648-800.jpg',
      description: 'Kakashi tests Team 7\'s abilities with the bell test.',
      arc: 'Introduction Arc'
    },
    {
      id: 5,
      title: 'Eat or Be Eaten: Panic in the Forest',
      number: 26,
      series: 'naruto',
      thumbnail: 'https://staticg.sportskeeda.com/editor/2021/12/1aa8e-16394248839809-1920.jpg',
      description: 'Team 7 enters the Forest of Death during the Chunin Exams.',
      arc: 'Chunin Exam Arc'
    },
    {
      id: 6,
      title: 'Gaara vs. Rock Lee: The Power of Youth Explodes!',
      number: 48,
      series: 'naruto',
      thumbnail: 'https://staticg.sportskeeda.com/editor/2021/10/7b4ae-16345778823989-1920.jpg',
      description: 'Rock Lee fights Gaara during the Chunin Exam preliminaries.',
      arc: 'Chunin Exam Arc'
    },
    {
      id: 7,
      title: 'A Killer Beetle: Sasuke\'s Decision',
      number: 82,
      series: 'naruto',
      thumbnail: 'https://staticg.sportskeeda.com/editor/2021/08/1ea94-16289063152471-1920.jpg',
      description: 'Sasuke decides to leave the Hidden Leaf Village.',
      arc: 'Sasuke Retrieval Arc'
    },
    {
      id: 8,
      title: 'Naruto\'s Plea',
      number: 109,
      series: 'naruto',
      thumbnail: 'https://staticg.sportskeeda.com/editor/2022/10/b4d4a-16657407273410-1920.jpg',
      description: 'Naruto fights Sasuke at the Valley of the End.',
      arc: 'Sasuke Retrieval Arc'
    },
    
    // Shippuden episodes
    {
      id: 101,
      title: 'Homecoming',
      number: 1,
      series: 'shippuden',
      thumbnail: 'https://staticg.sportskeeda.com/editor/2023/01/41ab9-16748051509906-1920.jpg',
      description: 'After training with Jiraiya for two and a half years, Naruto returns to the village.',
      arc: 'Kazekage Rescue Arc'
    },
    {
      id: 102,
      title: 'The Akatsuki Makes Its Move',
      number: 2,
      series: 'shippuden',
      thumbnail: 'https://staticg.sportskeeda.com/editor/2021/09/a9a80-16302369566151-800.jpg',
      description: 'The Akatsuki begins targeting jinchuriki, starting with Gaara.',
      arc: 'Kazekage Rescue Arc'
    },
    {
      id: 103,
      title: 'Sasuke and Sakura',
      number: 32,
      series: 'shippuden',
      thumbnail: 'https://staticg.sportskeeda.com/editor/2021/10/4b8db-16350307171988-800.jpg',
      description: 'Team 7 reunites with Sasuke for the first time since his departure.',
      arc: 'Tenchi Bridge Reconnaissance Arc'
    },
    {
      id: 104,
      title: 'The Results of Training',
      number: 86,
      series: 'shippuden',
      thumbnail: 'https://staticg.sportskeeda.com/editor/2021/09/1d4e0-16300614323398-1920.jpg',
      description: 'Naruto shows off his new Wind Release: Rasenshuriken technique.',
      arc: 'Immortal Guardians Arc'
    },
    {
      id: 105,
      title: 'Assault on the Hidden Leaf Village!',
      number: 162,
      series: 'shippuden',
      thumbnail: 'https://staticg.sportskeeda.com/editor/2022/08/f49fe-16596007548686-1920.jpg',
      description: 'Pain launches a full-scale attack on the Hidden Leaf Village.',
      arc: 'Pain\'s Assault Arc'
    },
    {
      id: 106,
      title: 'The Nine-Tails is Captured!',
      number: 295,
      series: 'shippuden',
      thumbnail: 'https://staticg.sportskeeda.com/editor/2022/06/2d15d-16559099873402-1920.jpg',
      description: 'The Ten-Tails is revived during the Fourth Great Ninja War.',
      arc: 'Fourth Great Ninja War Arc'
    },
    {
      id: 107,
      title: 'The Two Kings',
      number: 380,
      series: 'shippuden',
      thumbnail: 'https://staticg.sportskeeda.com/editor/2021/10/6e6d7-16351064977392-800.jpg',
      description: 'Madara becomes the Ten-Tails\' jinchuriki.',
      arc: 'Fourth Great Ninja War: Climax Arc'
    },
    {
      id: 108,
      title: 'The Final Battle',
      number: 476,
      series: 'shippuden',
      thumbnail: 'https://staticg.sportskeeda.com/editor/2021/02/a257c-16142289465510-800.jpg',
      description: 'Naruto and Sasuke have their final battle at the Valley of the End.',
      arc: 'Birth of the Ten-Tails\' Jinchuriki Arc'
    }
  ];
  
  const filterOptions = [
    { id: 'all', label: 'All Episodes' },
    { id: 'naruto', label: 'Naruto' },
    { id: 'shippuden', label: 'Shippuden' },
  ];
  
  const filteredEpisodes = allEpisodes
    .filter(episode => activeFilter === 'all' || episode.series === activeFilter)
    .filter(episode => 
      episode.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      episode.description.toLowerCase().includes(searchQuery.toLowerCase())
    );
  
  return (
    <div className="py-20 px-4">
      <div className="container mx-auto">
        <h1 className="text-4xl font-bold mb-2">Episodes</h1>
        <p className="text-gray-400 mb-10">Browse and watch all episodes from the Naruto series</p>
        
        {/* Search and filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-10">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search episodes..."
              className="w-full pl-10 pr-4 py-3 bg-secondary rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-naruto-orange"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <div className="flex items-center bg-secondary rounded-lg">
            <Filter className="mx-3 text-gray-400" />
            <div className="flex">
              {filterOptions.map(option => (
                <button
                  key={option.id}
                  className={`px-4 py-3 text-sm font-medium ${
                    activeFilter === option.id
                      ? 'bg-naruto-orange text-white'
                      : 'text-gray-300 hover:text-white'
                  } transition-colors rounded-lg`}
                  onClick={() => setActiveFilter(option.id)}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>
        </div>
        
        {/* Episodes grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredEpisodes.map((episode) => (
            <div key={episode.id} className="episode-card group relative">
              <div className="relative aspect-video overflow-hidden">
                <img 
                  src={episode.thumbnail} 
                  alt={episode.title} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-naruto-darkBlue via-transparent to-transparent"></div>
                
                <div className="absolute top-2 left-2">
                  <span className={`text-xs px-2 py-1 rounded ${
                    episode.series === 'naruto' ? 'bg-naruto-orange' : 'bg-naruto-red'
                  } text-white`}>
                    {episode.series === 'naruto' ? 'Naruto' : 'Shippuden'}
                  </span>
                </div>
                
                <div className="absolute top-2 right-2">
                  <span className="text-xs px-2 py-1 rounded bg-gray-800 text-white">
                    EP {episode.number}
                  </span>
                </div>
                
                <button className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-naruto-orange p-4 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-300 transform scale-50 group-hover:scale-100">
                  <Play className="h-6 w-6 text-white" />
                </button>
              </div>
              
              <div className="p-4">
                <div className="text-xs text-naruto-orange font-medium mb-1">{episode.arc}</div>
                <h3 className="font-bold text-white mb-2 line-clamp-1">{episode.title}</h3>
                <p className="text-gray-400 text-sm line-clamp-2">{episode.description}</p>
              </div>
              
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute inset-0 bg-naruto-darkBlue/70 backdrop-blur-sm"></div>
                <div className="absolute inset-0 flex items-center justify-center flex-col p-4 text-center">
                  <h3 className="font-bold text-white mb-2">{episode.title}</h3>
                  <p className="text-gray-300 text-sm mb-4">{episode.description}</p>
                  <button className="chakra-btn text-sm">Watch Now</button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {filteredEpisodes.length === 0 && (
          <div className="text-center py-20">
            <h3 className="text-2xl font-bold mb-2">No episodes found</h3>
            <p className="text-gray-400">Try adjusting your search or filter criteria</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default EpisodesPage;
