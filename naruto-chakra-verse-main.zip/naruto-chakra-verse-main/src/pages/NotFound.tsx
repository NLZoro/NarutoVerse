
import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Link } from "react-router-dom";
import { Home } from "lucide-react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-naruto-darkBlue px-4">
      <div className="text-center max-w-lg">
        <h1 className="text-8xl font-bold text-naruto-orange mb-4">404</h1>
        <p className="text-2xl text-white mb-8">Oops! This page is lost in the Shadow Realm</p>
        <p className="text-gray-400 mb-8">Even with the Byakugan, we couldn't find the page you're looking for.</p>
        <Link 
          to="/" 
          className="chakra-btn inline-flex items-center"
        >
          <Home className="mr-2 h-5 w-5" />
          Return to the Hidden Leaf
        </Link>
      </div>
    </div>
  );
};

export default NotFound;
